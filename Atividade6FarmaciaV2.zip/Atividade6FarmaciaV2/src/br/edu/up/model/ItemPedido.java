package br.edu.up.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

@Entity 
@Table (name = "itensPedido")
@TableGenerator(
	name = "gerador_de_id_ItensPedido",
	table = "sqlite_sequence",
	pkColumnName = "name",
	valueColumnName = "seq",
	pkColumnValue = "itensPedido",
	initialValue = 1,
	allocationSize = 1
		
)

public class ItemPedido {
	
	@Id
	@GeneratedValue (strategy = GenerationType.TABLE, generator = "gerador_de_id_ItensPedido")
	private int id;
	//private int idPedido;
	private String nome;
	private int qtd;
	private double preco;
	
	//INSERT INTO itensPedido (ID, IDPEDIDO, NOME, PRECO, QTD, PEDIDO_ID) VALUES (?, ?, ?, ?, ?, ?)
	
	//@ManyToOne
	//@JoinColumn(name="idPedido")
	//@Transient 
	private Pedido pedido;
	
	public Pedido getPedido() {
		return pedido;
	}

	public void setPedido(Pedido pedido) {
		this.pedido = pedido;
	}

	//Construtor vazio
	public ItemPedido() {
	}
	
	//Construtor que recebe todos, exceto id
	public ItemPedido(String nome, int qtd, double preco) {
	super();
	//this.idPedido = idPedido;
	this.nome = nome;
	this.qtd = qtd;
	this.preco = preco;
	}
	
	//Construtor que recebe todos
	public ItemPedido(int id, String nome, int qtd, double preco) {
	super();
	this.id = id;
	//this.idPedido = idPedido;
	this.nome = nome;
	this.qtd = qtd;
	this.preco = preco;
	}
	
		
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public int getQtd() {
		return qtd;
	}
	public void setQtd(int qtd) {
		this.qtd = qtd;
	}
	public double getPreco() {
		return preco;
	}
	public void setPreco(double preco) {
		this.preco = preco;
	}
}
