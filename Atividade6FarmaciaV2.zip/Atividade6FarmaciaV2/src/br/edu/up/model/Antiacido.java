package br.edu.up.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.TableGenerator;

@Entity
@TableGenerator(
		name = "gerador_de_ip_antiacido",
		table = "sqlite_sequence",
		pkColumnName = "name",
		valueColumnName = "seq",
		pkColumnValue = "antiacido",
		initialValue = 1,
		allocationSize = 1		
)
public class Antiacido {
	
	@Id
	@GeneratedValue (strategy = GenerationType.TABLE, generator = "gerador_de_ip_antiacido")
	private int id;
	private String nome;
	private double preco;
	
	//Construtor vazio
	public Antiacido() {
	}
		
	//Construtor que recebe nome e pre�o
	public Antiacido(String nome, double preco) {
		super();
		this.nome = nome;
		this.preco = preco;
	}
	
	//Construtor que recebe id, nome, pre�o
	public Antiacido(int id, String nome, double preco) {
		super();
		this.id = id;
		this.nome = nome;
		this.preco = preco;
	}



	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public double getPreco() {
		return preco;
	}
	public void setPreco(double preco) {
		this.preco = preco;
	}

}
