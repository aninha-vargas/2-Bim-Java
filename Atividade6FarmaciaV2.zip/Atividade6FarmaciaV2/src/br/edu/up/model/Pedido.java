package br.edu.up.model;

import java.util.List;
import java.util.ArrayList;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.TableGenerator;

@Entity
@TableGenerator(
	name = "gerador_de_ip_Pedido",
	table = "sqlite_sequence",
	pkColumnName = "name",
	valueColumnName = "seq",
	pkColumnValue = "pedido",
	initialValue = 1,
	allocationSize = 1
		
)


public class Pedido {
	
	@Id
	@GeneratedValue (strategy = GenerationType.TABLE, generator = "gerador_de_ip_Pedido")
	private int id;
	private Date dataPedido;
	
	@OneToMany(mappedBy="pedido")
	private List<ItemPedido> listaDeItens = new ArrayList<ItemPedido>();
	
	public void adicionarItemPedido(ItemPedido item) {
		listaDeItens.add(item);
	}
	
	//Construtor vazio
	public Pedido() {
	}
	
	//Construtor que recebe todos, exceto id
	public Pedido( Date dataPedido) {
	super();
	this.dataPedido = dataPedido;
	}
	
	//Construtor que recebe todos
	public Pedido(int id, Date dataPedido) {
	super();
	this.id = id;
	this.dataPedido = dataPedido;
	}
	

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Date getDataPedido() {
		return dataPedido;
	}

	public void setDataPedido(Date dataPedido) {
		this.dataPedido = dataPedido;
	}

	public List<ItemPedido> getItenspedidos() {
		return listaDeItens;
	}

	public void setItenspedidos(List<ItemPedido> itenspedidos) {
		this.listaDeItens = itenspedidos;
	}
	
	

}
