package br.edu.up.dao;

import br.edu.up.model.ItemPedido;

public class ItemPedidoDAO extends GenericDAO<ItemPedido>{

}
