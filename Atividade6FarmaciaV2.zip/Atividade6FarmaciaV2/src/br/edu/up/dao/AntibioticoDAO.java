package br.edu.up.dao;

import br.edu.up.model.Antibiotico;

public class AntibioticoDAO extends GenericDAO<Antibiotico> {

	
}
