package br.edu.up.dao;

import br.edu.up.model.Pedido;

public class PedidoDAO extends GenericDAO<Pedido> {

}
