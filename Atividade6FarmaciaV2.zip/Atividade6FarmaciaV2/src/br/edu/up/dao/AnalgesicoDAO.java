package br.edu.up.dao;

import br.edu.up.model.Analgesico;

public class AnalgesicoDAO extends GenericDAO<Analgesico> {

}
