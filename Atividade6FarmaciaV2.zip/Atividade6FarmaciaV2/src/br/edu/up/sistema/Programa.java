package br.edu.up.sistema;

import java.io.FileNotFoundException;
import java.sql.SQLException;
import java.util.Scanner;

public class Programa {
	
	public static void main (String[] args) throws SQLException, FileNotFoundException {
		
		Scanner leitor = new Scanner(System.in);
	    System.out.println();
	    System.out.println("*************OP��ES***************");
	    System.out.println();
	    System.out.println("   1  -  ACESSO GEST�O");
		System.out.println("   2  -  ACESSO ATENDIMENTO");
		System.out.println();
		System.out.println("**********************************");
		System.out.println();
		System.out.println("DIGITE SUA OP��O: ");
		int opcao = leitor.nextInt();
		leitor.nextLine();
		System.out.println();
	    
		if (opcao == 1) {
			Gestao.processar();
		}
		if (opcao == 2) {
			Atendimento.processar();
		}
	    
	    leitor.close();
	}
}